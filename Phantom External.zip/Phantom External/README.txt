How to use:
-------------------

] Open Phantom and enter any license key

-------------------
cracked by @glyphaj
-------------------